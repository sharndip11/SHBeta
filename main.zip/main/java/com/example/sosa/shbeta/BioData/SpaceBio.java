package com.example.sosa.shbeta.BioData;

/**
 * Created by Sharndip on 11/04/2017.
 */

public class SpaceBio {

    String name;
    int image;

    public SpaceBio() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

}
