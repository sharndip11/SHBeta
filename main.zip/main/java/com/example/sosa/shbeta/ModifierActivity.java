package com.example.sosa.shbeta;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModifierActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, LoaderManager.LoaderCallbacks<Cursor> {
    private UserEditTask mEditTask = null;
    private EditText mEmailView;
    private EditText mNomView;
    private EditText mPrenomView;
    private EditText mPasswordView;
    private EditText mConfirmPasswordView;
    private View mProgressView;
    private View mEditFormView;
    int id = 0;
    String nom = new String();
    String nom_prenom = new String();
    String prenom = new String();
    String email = new String();
    String mdp = new String();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifinfo);

        //ON DECLARE UN OBJET DE SESSION
        final Session session = new Session(getApplicationContext());

        //ON EFFECTUE LES ACTIONS EN BASE NECESSAIRE POUR L AFFICHAGE DES INFORMATIONS
        DBHandler db = new DBHandler(this);
        List<Utilisateur> liste_utilisateur = db.getAllUtilisateur();

        for (Utilisateur utilisateur : liste_utilisateur) {
            if (utilisateur.getId() == session.getIdUtilisateur()) {
                id = utilisateur.getId();
                nom_prenom = utilisateur.getPrenom() + " " + utilisateur.getNom();
                email = utilisateur.getMail();
                nom = utilisateur.getNom();
                prenom = utilisateur.getPrenom();
                mdp = utilisateur.getPass();
            }
        }

        //ON DECLARE LA BARRE D OUTIL ET LE BOUTON FLOTANT
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        //ON DECLARE LES ELEMENTS DE LA PAGE DE LA FAQ
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header_utilisateur = navigationView.getHeaderView(0);
        TextView npView =(TextView)header_utilisateur.findViewById(R.id.nomPrenomView);
        TextView eView =(TextView)header_utilisateur.findViewById(R.id.emailView);
        TextView nomView = (TextView)findViewById(R.id.NomView);
        TextView prenomView = (TextView)findViewById(R.id.PrenomView);
        TextView emailView = (TextView)findViewById(R.id.EmailView);
        TextView mdpView = (TextView)findViewById(R.id.MdpView);

        //ON SET LES VUES AVEC LES INFORMATIONS CORRESPONDANTES
        navigationView.setNavigationItemSelectedListener(this);
        npView.setText(nom_prenom);
        eView.setText(email);
        nomView.setText(nom);
        prenomView.setText(prenom);
        emailView.setText(email);
        mdpView.setText(mdp);

        //ON DECLARE DANS LE CODE LES ELEMENTS DE LA VUE
        mNomView = (EditText) findViewById(R.id.nom);
        mPrenomView = (EditText) findViewById(R.id.prenom);
        mEmailView = (EditText) findViewById(R.id.email);
        mPasswordView = (EditText) findViewById(R.id.password);
        mConfirmPasswordView = (EditText) findViewById(R.id.confirm_password);
        mEditFormView = findViewById(R.id.edit_form);
        mProgressView = findViewById(R.id.edit_progress);
        Button mEditButton = (Button) findViewById(R.id.edit_button);

        //ON ECOUTE SUR LE CHAMP 'CONFIRMER'
        mConfirmPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.edit_info || id == EditorInfo.IME_NULL) {
                    attemptEdit(id, nom, prenom, email, mdp);
                    return true;
                }
                return false;
            }
        });

        //ON ECOUTE SUR LE BOUTON 'MODIFIER' ET ON EFFECTUE L ACTION
        mEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptEdit(id, nom, prenom, email, mdp);
            }
        });

        db.close();
    }

    //ON GERE LE COMPORTEMENT DU BOUTON RETOUR
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    //ON VERIFIE LES INFORMATIONS POUR EFFECTUER LA MODIFICATION
    private void attemptEdit(int _id, String _nom, String _prenom, String _email, String _mdp) {
        //ON DECLARE UN OBJET DE SESSION
        Session session = new Session(getApplicationContext());

        if (mEditTask != null) {
            return;
        }

        //ON REINITIALISE LES ERREURS
        mEmailView.setError(null);
        mPasswordView.setError(null);
        mConfirmPasswordView.setError(null);
        mNomView.setError(null);
        mPrenomView.setError(null);

        //ON STOCK LES VALEURS SAISIES
        String email = mEmailView.getText().toString();
        String password = mPasswordView.getText().toString();
        String nom = mNomView.getText().toString();
        String prenom = mPrenomView.getText().toString();
        String confirmPassword = mConfirmPasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        //ON VERIFIE LE MDP
        if (TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            mPasswordView.setError(getString(R.string.error_field_required));
            mConfirmPasswordView.setError(getString(R.string.error_field_required));
            if (TextUtils.isEmpty(password)) {
                focusView = mPasswordView;
            } else {
                focusView = mConfirmPasswordView;
            }
            cancel = true;
        } else if (!isPassValid(password, confirmPassword)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            mConfirmPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        } else if (_mdp == password) {
            mPasswordView.setError(getString(R.string.error_already_exist));
            mConfirmPasswordView.setError(getString(R.string.error_already_exist));
            focusView = mPasswordView;
            cancel = true;
        }

        //ON VERIFIE LE  MAIL
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            cancel = true;
        } else if (_email == email) {
            mEmailView.setError(getString(R.string.error_already_exist));
            focusView = mEmailView;
            cancel = true;
        }

        //ON VERIFIE LE PRENOM
        if (TextUtils.isEmpty(prenom)) {
            mPrenomView.setError(getString(R.string.error_field_required));
            focusView = mPrenomView;
            cancel = true;
        } else if (!isNameValid(prenom)) {
            mPrenomView.setError(getString(R.string.error_invalid_lastname));
            focusView = mPrenomView;
            cancel = true;
        } else if (_prenom == prenom) {
            mPrenomView.setError(getString(R.string.error_already_exist));
            focusView = mPrenomView;
            cancel = true;
        }

        //ON VERIFIE LE NOM
        if (TextUtils.isEmpty(nom)) {
            mNomView.setError(getString(R.string.error_field_required));
            focusView = mNomView;
            cancel = true;
        } else if (!isNameValid(nom)) {
            mNomView.setError(getString(R.string.error_invalid_firstname));
            focusView = mNomView;
            cancel = true;
        } else if (_nom == nom) {
            mNomView.setError(getString(R.string.error_already_exist));
            focusView = mNomView;
            cancel = true;
        }


        //ON SE FOCALISE SUR LE CHAMP AYANT GENERE UNE ERREUR OU ALORS ON AFFICHE LE SPINNER TOUT
        //EN EFFECTUANT LA TACHE DE REGISTER EN BACKGROUND
        //ON SET EN SESSION UN ID EN FONCTION POUR EVITERPAR LA SUITE UNE REINITIALISATION DE LA BASE
        if (cancel) {
            focusView.requestFocus();
            session.setIndexRegistration(false);
        } else {
            showProgress(true);
            mEditTask = new UserEditTask(id, nom, prenom, email, password, confirmPassword);
            session.setIndexRegistration(true);
            mEditTask.execute((Void) null);
        }
    }

    //ON AFFICHE LA PROGRESSION ET ON MASQUE LE FORMULAIRE DE REGISTER
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);
            mEditFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mEditFormView.animate().setDuration(shortAnimTime).alpha(show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mEditFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mEditFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    private interface ProfileQuery {
        String[] PROJECTION = {
                ContactsContract.CommonDataKinds.Email.ADDRESS,
                ContactsContract.CommonDataKinds.Email.IS_PRIMARY,
        };
        int ADDRESS = 0;
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        return new CursorLoader(this,
                Uri.withAppendedPath(ContactsContract.Profile.CONTENT_URI,
                        ContactsContract.Contacts.Data.CONTENT_DIRECTORY),
                ModifierActivity.ProfileQuery.PROJECTION,
                ContactsContract.Contacts.Data.MIMETYPE + " = ?",
                new String[]{ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE},
                ContactsContract.Contacts.Data.IS_PRIMARY + " DESC");
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {
        List<String> emails = new ArrayList<>();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            emails.add(cursor.getString(ModifierActivity.ProfileQuery.ADDRESS));
            cursor.moveToNext();
        }
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {return true;}
        return super.onOptionsItemSelected(item);
    }

    //ON VALIDE LES NOMS
    private boolean isNameValid(String name) {
        return (!name.isEmpty() && name.length() > 1);
    }

    //ON VALIDE LE MAIL
    private boolean isEmailValid(String email) {
        return email.contains("@");
    }

    //ON VALIDE LE MDP
    private boolean isPassValid(String password, String confirmPassword) {
        return (password.equals(confirmPassword) && password.length() > 4 && confirmPassword.length() > 4);
    }

    //ON SELECTIONNE UN ITEM DANS LE MENU LATERAL ET ON DEMARE L ACTIVITE ASSOCIEE
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        Session session = new Session(getApplicationContext());
        Intent selection_intent = null;

        if (id == R.id.nav_accueil) {
            selection_intent = new Intent(ModifierActivity.this, MenuActivity.class);
        } else if (id == R.id.nav_viesikh) {
            selection_intent = new Intent(ModifierActivity.this, VieSikhActivity.class);
        } else if (id == R.id.nav_histoire) {
            //selection_intent = new Intent(ModifierActivity.this, HistoireActivity.class);
        } else if (id == R.id.nav_biographies) {
            //selection_intent = new Intent(ModifierActivity.this, BiographieActivity.class);
        } else if (id == R.id.nav_temples) {
            //selection_intent = new Intent(ModifierActivity.this, TempleActivity.class);
        } else if (id == R.id.nav_faq) {
            selection_intent = new Intent(ModifierActivity.this, FAQActivity.class);
        } else if (id == R.id.nav_quizz) {
            //selection_intent = new Intent(ModifierActivity.this, QuizzActivity.class);
        } else if (id == R.id.nav_actualites) {
            //selection_intent = new Intent(ModifierActivity.this, ActualiteActivity.class);
        }  else if (id == R.id.nav_logout) {
            session.setIndexFirstConnexion(42);
            selection_intent = new Intent(ModifierActivity.this, ReCoActivity.class);
        } else if (id == R.id.edit_info) {
            selection_intent = new Intent(ModifierActivity.this, ModifierActivity.class);
        }
        startActivity(selection_intent);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //ON CREE UNE TACHE DE EDIT OU ON FAIT CE QUE L ON SOUHAITE EN ATTENDANT LE CHARGEMENT
    public class UserEditTask extends AsyncTask<Void, Void, Boolean> {
        private final String mEmail;
        private final String mPassword;
        private final String mConfirmPassword;
        private final String mNom;
        private final String mPrenom;

        //ON INSCRIT L UTILISATEUR EN BASE
        UserEditTask(int id, String nom, String prenom, String email, String password, String confirmPassword) {
            DBHandler db = new DBHandler(getApplicationContext());

            Log.d("Edit ", "Modification...");
            //db.ajouterUtilisateur(new Utilisateur(1, nom, prenom, email, password));
            db.modifierUtilisateur(id, nom, prenom, email, password);
            mEmail = email;
            mNom = nom;
            mPrenom = prenom;
            mPassword = password;
            mConfirmPassword = confirmPassword;
            Log.d("UserEditTask ", "[New M: " + mEmail + " | New P: " + mPassword +
                    " | New N: " + mNom + " | New P: " + mPrenom + "]");
            db.close();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: remplacer par ce que l'on veut pendant le chargement au spinner.
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return false;
            }
            return true;
        }
        @Override
        protected void onPostExecute(final Boolean success) {
            mEditTask = null;
            showProgress(false);
            if (success) {
                //ON REDIRIGE l UTILISATEUR SUR LA PAGE DE LOGIN APRES SUCCES DE L INSCRIPTION
                Intent intent = new Intent(ModifierActivity.this, ReCoActivity.class);
                startActivity(intent);
                finish();
            } else {
                //ON SE FOCALISE SUR UNE ERREUR DE LOGIN [MDP pour le moment]
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mEditTask = null;
            showProgress(false);
        }
    }
}
