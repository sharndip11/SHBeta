package com.example.sosa.shbeta;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FAQActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);

        //ON DECLARE UN OBJET DE SESSION
        final Session session = new Session(getApplicationContext());

        //ON EFFECTUE LES ACTIONS EN BASE NECESSAIRE POUR L AFFICHAGE DES INFORMATIONS
        DBHandler db = new DBHandler(this);
        List<Utilisateur> liste_utilisateur = db.getAllUtilisateur();
        List<FAQQuestion> liste_question = db.getAllFAQQuestion();
        //int nombre_question = db.getNombreQuestion();
        String nom_prenom = new String();
        String email = new String();

        for (Utilisateur utilisateur : liste_utilisateur) {
            if (utilisateur.getId() == session.getIdUtilisateur()) {
                nom_prenom = utilisateur.getPrenom() + " " + utilisateur.getNom();
                email = utilisateur.getMail();
            }
        }

        //ON DECLARE LA BARRE D OUTIL ET LE BOUTON FLOTANT
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        //ON DECLARE LES ELEMENTS DE LA PAGE DE LA FAQ
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header_utilisateur = navigationView.getHeaderView(0);
        TextView npView =(TextView)header_utilisateur.findViewById(R.id.nomPrenomView);
        TextView eView =(TextView)header_utilisateur.findViewById(R.id.emailView);
        TextView intitule_sujet_1 = (TextView)findViewById(R.id.sujet_1);
        TextView intitule_sujet_2 = (TextView)findViewById(R.id.sujet_2);
        TextView intitule_sujet_3 = (TextView)findViewById(R.id.sujet_3);




        Map<Integer, String> sujets = new HashMap<Integer, String>();
        Map<Integer, String> contenus = new HashMap<>();
        int i = 0;
        while (i <= liste_question.size() - 1) {
            sujets.put(i, liste_question.get(i).getIntitule());
            contenus.put(i, liste_question.get(i).getContenu());
            i++;
        }
        i = 0;
        while (i <= liste_question.size() - 1) {
                if (i % 3 == 0) {
                    final int i_stock = (i % 3) + 1;
                    intitule_sujet_1.setText(sujets.get(i));
                    intitule_sujet_1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent_sujet1 = new Intent(FAQActivity.this, FAQDescActivity.class);
                            session.setIdSujetFAQ(i_stock);
                            startActivity(intent_sujet1);
                        }
                    });
                }

                if (i % 3 == 1) {
                    final int i_stock = (i % 3) + 1;
                    intitule_sujet_2.setText(sujets.get(i));
                    intitule_sujet_2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent_sujet2 = new Intent(FAQActivity.this, FAQDescActivity.class);
                            session.setIdSujetFAQ(i_stock);
                            startActivity(intent_sujet2);
                        }
                    });
                }

                if (i % 3 == 2) {
                    final int i_stock = (i % 3) + 1;
                    intitule_sujet_3.setText(sujets.get(i));
                    intitule_sujet_3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent_sujet3 = new Intent(FAQActivity.this, FAQDescActivity.class);
                            session.setIdSujetFAQ(i_stock);
                            startActivity(intent_sujet3);
                        }
                    });
                }
            i++;
        }
        i = 0;
        Log.d("bin", " return " + i);

        //ON SET LES VUES AVEC LES INFORMATIONS CORRESPONDANTES
        navigationView.setNavigationItemSelectedListener(this);
        npView.setText(nom_prenom);
        eView.setText(email);
        db.close();
    }

    //ON GERE LE COMPORTEMENT DU BOUTON RETOUR
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {return true;}
        return super.onOptionsItemSelected(item);
    }

    //ON SELECTIONNE UN ITEM DANS LE MENU LATERAL ET ON DEMARE L ACTIVITE ASSOCIEE
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        Session session = new Session(getApplicationContext());
        Intent selection_intent = null;

        if (id == R.id.nav_accueil) {
            selection_intent = new Intent(FAQActivity.this, MenuActivity.class);
        } else if (id == R.id.nav_viesikh) {
            selection_intent = new Intent(FAQActivity.this, VieSikhActivity.class);
        } else if (id == R.id.nav_histoire) {
            selection_intent = new Intent(FAQActivity.this, HistoireActivity.class);
        } else if (id == R.id.nav_biographies) {
            selection_intent = new Intent(FAQActivity.this, BiographieActivity.class);
        } else if (id == R.id.nav_temples) {
            //selection_intent = new Intent(FAQActivity.this, TempleActivity.class);
        } else if (id == R.id.nav_faq) {
            selection_intent = new Intent(FAQActivity.this, FAQActivity.class);
        } else if (id == R.id.nav_quizz) {
            //selection_intent = new Intent(FAQActivity.this, QuizzActivity.class);
        } else if (id == R.id.nav_actualites) {
            //selection_intent = new Intent(FAQActivity.this, ActualiteActivity.class);
        }  else if (id == R.id.nav_logout) {
            session.setIndexFirstConnexion(42);
            selection_intent = new Intent(FAQActivity.this, ReCoActivity.class);
        } else if (id == R.id.edit_info) {
            selection_intent = new Intent(FAQActivity.this, ModifierActivity.class);
        }
        startActivity(selection_intent);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
