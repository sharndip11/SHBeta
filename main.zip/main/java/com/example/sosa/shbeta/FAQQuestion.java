package com.example.sosa.shbeta;

/**
 * Created by sosa on 06/01/17.
 */

public class FAQQuestion {
    private int id;
    private String intitule;
    private String contenu;
    private String pn_utilisateur;
    private int id_utilisateur;

    public FAQQuestion() {}

    public FAQQuestion(int _id, String _intitule, String _contenu, String _pn_utilisateur, int _id_utilisateur) {
        this.id = _id;
        this.intitule = _intitule;
        this.pn_utilisateur = _pn_utilisateur;
        this.contenu = _contenu  + " - " + _pn_utilisateur;
        this.id_utilisateur = _id_utilisateur;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public String getPn_utilisateur() {
        return pn_utilisateur;
    }

    public void setPn_utilisateur(String pn_utilisateur) {
        this.pn_utilisateur = pn_utilisateur;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public int getId_utilisateur() {
        return id_utilisateur;
    }

    public void setId_utilisateur(int id_utilisateur) {
        this.id_utilisateur = id_utilisateur;
    }
}
