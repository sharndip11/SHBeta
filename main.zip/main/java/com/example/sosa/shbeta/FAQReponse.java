package com.example.sosa.shbeta;

/**
 * Created by sosa on 06/01/17.
 */

public class FAQReponse {
    private int id;
    private String pn_utilisateur;
    private String contenu;
    private int id_ref_q;
    private int id_utilisateur;

    public FAQReponse() {

    }

    public FAQReponse(int _id, String _pn_utilisateur, String _contenu, int _id_ref_q, int _id_utilisateur) {
        this.id = _id;
        this.contenu = _contenu;
        this.pn_utilisateur = _pn_utilisateur;
        this.id_ref_q = _id_ref_q;
        this.id_utilisateur = _id_utilisateur;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPn_utilisateur() {
        return pn_utilisateur;
    }

    public void setPn_utilisateur(String pn_utilisateur) {
        this.pn_utilisateur = pn_utilisateur;
    }

    public int getId_ref_q() {
        return id_ref_q;
    }

    public void setId_ref_q(int id_ref_q) {
        this.id_ref_q = id_ref_q;
    }

    public int getId_utilisateur() {
        return id_utilisateur;
    }

    public void setId_utilisateur(int id_utilisateur) {
        this.id_utilisateur = id_utilisateur;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }
}
