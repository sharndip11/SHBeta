package com.example.sosa.shbeta;

/**
 * Created by sosa on 06/01/17.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {
    private static final int VERSION_BDD = 1;
    private static final String NOM_BDD = "sikheritage";
    private static final String TABLE_UTILISATEUR = "utilisateur";
    private static final String TABLE_QUESTION_FAQ = "questionfaq";
    private static final String TABLE_REPONSE_FAQ = "reponsefaq";
    private static final String ID_UTILISATEUR = "id";
    private static final String NOM_UTILISATEUR = "nom";
    private static final String PRENOM_UTILISATEUR = "prenom";
    private static final String MAIL_UTILISATEUR = "mail";
    private static final String MDP_UTILISATEUR = "pass";
    private static final String ID_QUESTION_UTILISATEUR = "id_question";
    private static final String ID_REPONSE_UTILISATEUR = "id_reponse";
    private static final String ID_FAQ_QUESTION = "id";
    private static final String ID_FAQ_REPONSE = "id";
    private static final String INTITULE_FAQQ = "intitule";
    private static final String INTITULE_FAQR = "intitule";
    private static final String CONTENU_FAQQ = "contenu";
    private static final String CONTENU_FAQR = "contenu";
    private static final String ID_REFERENCE_QUESTION = "id_ref_q";
    private static final String ID_UTILISATEUR_QUESTION = "id_utilisateur";
    private static final String PN_UTILISATEUR_QUESTION = "pn_utilisateur";
    private static final String ID_UTILISATEUR_REPONSE = "id_utilisateur";
    private static final String PN_UTILISATEUR_REPONSE = "pn_utilisateur";

    public DBHandler(Context context) {
        super(context, NOM_BDD, null, VERSION_BDD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREER_TABLE_QUESTION_FAQ =
                "CREATE TABLE " + TABLE_QUESTION_FAQ + "(" +
                        ID_FAQ_QUESTION + " INTEGER PRIMARY KEY," +
                        INTITULE_FAQQ + " TEXT," +
                        CONTENU_FAQQ + " TEXT," +
                        PN_UTILISATEUR_QUESTION + " TEXT," +
                        ID_UTILISATEUR_QUESTION + " INTEGER," +
                        " FOREIGN KEY(" + ID_UTILISATEUR_QUESTION +
                            ") REFERENCES " + TABLE_UTILISATEUR + "(" + ID_UTILISATEUR + "))";

        String CREER_TABLE_REPONSE_FAQ =
                "CREATE TABLE " + TABLE_REPONSE_FAQ + "(" +
                        ID_FAQ_REPONSE + " INTEGER PRIMARY KEY," +
                        CONTENU_FAQR + " TEXT," +
                        PN_UTILISATEUR_REPONSE + " TEXT," +
                        ID_REFERENCE_QUESTION + " INTEGER," +
                        ID_UTILISATEUR_REPONSE + " INTEGER," +
                        " FOREIGN KEY(" + ID_UTILISATEUR_REPONSE +
                                ") REFERENCES " + TABLE_UTILISATEUR + "(" + ID_UTILISATEUR + "))";

        String CREER_TABLE_UTILISATEUR =
                "CREATE TABLE " + TABLE_UTILISATEUR + "(" +
                        ID_UTILISATEUR + " INTEGER PRIMARY KEY," +
                        NOM_UTILISATEUR + " TEXT," +
                        PRENOM_UTILISATEUR + " TEXT," +
                        MAIL_UTILISATEUR + " TEXT," +
                        MDP_UTILISATEUR + " TEXT," +
                        ID_QUESTION_UTILISATEUR + " INTEGER," +
                        ID_REPONSE_UTILISATEUR + " INTEGER," +
                        " FOREIGN KEY(" + ID_QUESTION_UTILISATEUR +
                                ") REFERENCES " + TABLE_QUESTION_FAQ + "(" + ID_FAQ_QUESTION + ")," +
                        " FOREIGN KEY(" + ID_REPONSE_UTILISATEUR +
                                ") REFERENCES " + TABLE_REPONSE_FAQ + "(" + ID_FAQ_REPONSE + "))";
        db.execSQL(CREER_TABLE_QUESTION_FAQ);
        db.execSQL(CREER_TABLE_REPONSE_FAQ);
        db.execSQL(CREER_TABLE_UTILISATEUR);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int ancienne_version, int nouvelle_version) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_UTILISATEUR);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPONSE_FAQ);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTION_FAQ);
        onCreate(db);
    }

    //AJOUTER UNE QUESTION DE LA FAQ
    public void ajouterFAQQuestion(FAQQuestion question) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valeur = new ContentValues();
        valeur.put(INTITULE_FAQQ, question.getIntitule());
        valeur.put(CONTENU_FAQQ, question.getContenu());
        valeur.put(PN_UTILISATEUR_QUESTION, question.getPn_utilisateur());
        valeur.put(ID_UTILISATEUR_QUESTION, question.getId_utilisateur());
        db.insert(TABLE_QUESTION_FAQ, null, valeur);
        db.close();
    }

    //RECUPERER UNE QUESTION DE LA FAQ
    public FAQQuestion getFAQQuestion(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.query(TABLE_QUESTION_FAQ, new String[] { ID_FAQ_QUESTION,
                                        INTITULE_FAQQ, CONTENU_FAQQ, PN_UTILISATEUR_QUESTION, ID_UTILISATEUR_QUESTION},
                                    ID_FAQ_QUESTION + "=?", new String[] {
                                        String.valueOf(id) }, null, null,
                                    null, null);
        curseur.moveToFirst();
        FAQQuestion _q = new FAQQuestion(Integer.parseInt(curseur.getString(0)),
                curseur.getString(1), curseur.getString(2), curseur.getString(3), Integer.parseInt(curseur.getString(4)));
        return _q;
    }

    //RECUPERER TOUTES LES QUESTIONS
    public List<FAQQuestion> getAllFAQQuestion() {
        List<FAQQuestion> liste_question = new ArrayList<FAQQuestion>();
        String selectQuery = "SELECT * FROM " + TABLE_QUESTION_FAQ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor curseur = db.rawQuery(selectQuery, null);
        if(curseur.moveToFirst()) {
            do {
                FAQQuestion question = new FAQQuestion();
                question.setId(Integer.parseInt(curseur.getString(0)));
                question.setIntitule(curseur.getString(1));
                question.setContenu(curseur.getString(2));
                question.setPn_utilisateur(curseur.getString(3));
                question.setId_utilisateur(Integer.parseInt(curseur.getString(4)));
                liste_question.add(question);
            } while (curseur.moveToNext());
        }
        return liste_question;
    }

    //RECUPERER LE NOMBRE TOTAL DE QUESTIONS
    public int getNombreQuestion() {
        String countQuery = "SELECT * FROM " + TABLE_QUESTION_FAQ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.rawQuery(countQuery, null);
        curseur.close();
        return curseur.getCount();
    }

    public void supprimerAllFAQQuestion() {
        String deleteQuery = "DELETE FROM " + TABLE_QUESTION_FAQ;
        getWritableDatabase().execSQL(deleteQuery);
    }

    //AJOUTER UN UTILISATEUR
    public void ajouterUtilisateur(Utilisateur utilisateur) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valeur = new ContentValues();
        valeur.put(NOM_UTILISATEUR, utilisateur.getNom());
        valeur.put(PRENOM_UTILISATEUR, utilisateur.getPrenom());
        valeur.put(MAIL_UTILISATEUR, utilisateur.getMail());
        valeur.put(MDP_UTILISATEUR, utilisateur.getPass());
        db.insert(TABLE_UTILISATEUR, null, valeur);
        //db.close();
    }

    public void modifierUtilisateur(int _id, String _nom, String _prenom, String _email, String _password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(NOM_UTILISATEUR, _nom);
        cv.put(PRENOM_UTILISATEUR, _prenom);
        cv.put(MAIL_UTILISATEUR, _email);
        cv.put(MDP_UTILISATEUR, _password);
        db.update(TABLE_UTILISATEUR, cv, ID_UTILISATEUR + "=" + _id , null);
    }
    //RECUPERER UN UTILISATEUR
    public Utilisateur getUtilisateur(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.query(TABLE_UTILISATEUR, new String[] { ID_UTILISATEUR,
                        NOM_UTILISATEUR, PRENOM_UTILISATEUR,
                        MAIL_UTILISATEUR, MDP_UTILISATEUR },
                ID_UTILISATEUR + "=?", new String[] {
                        String.valueOf(id) }, null, null,
                null, null);
        curseur.moveToFirst();
        Utilisateur _u = new Utilisateur(Integer.parseInt(curseur.getString(0)),
                curseur.getString(1), curseur.getString(2), curseur.getString(3),
                curseur.getString(4));
        return _u;
    }

    //RECUPERER TOUS LES UTILISATEURS
    public List<Utilisateur> getAllUtilisateur() {
        List<Utilisateur> liste_utilisateur = new ArrayList<Utilisateur>();
        String selectQuery = "SELECT * FROM " + TABLE_UTILISATEUR;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor curseur = db.rawQuery(selectQuery, null);
        if(curseur.moveToFirst()) {
            do {
                Utilisateur utilisateur = new Utilisateur();
                utilisateur.setId(Integer.parseInt(curseur.getString(0)));
                utilisateur.setNom(curseur.getString(1));
                utilisateur.setPrenom(curseur.getString(2));
                utilisateur.setMail(curseur.getString(3));
                utilisateur.setPass(curseur.getString(4));
                liste_utilisateur.add(utilisateur);
            } while (curseur.moveToNext());
        }
        return liste_utilisateur;
    }

    //RECUPERER LE NOMBRE TOTAL D'UTILISATEURS
    public int getNombreUtilisateur() {
        String countQuery = "SELECT * FROM " + TABLE_UTILISATEUR;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.rawQuery(countQuery, null);
        curseur.close();
        return curseur.getCount();
    }

    public void supprimerAllUtilisateur() {
        String deleteQuery = "DELETE FROM " + TABLE_UTILISATEUR;
        getWritableDatabase().execSQL(deleteQuery);
    }

    //AJOUTER UNE REPONSE DE LA FAQ
    public void ajouterFAQReponse(FAQReponse reponse) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valeur = new ContentValues();
        valeur.put(CONTENU_FAQR, reponse.getContenu());
        valeur.put(PN_UTILISATEUR_QUESTION, reponse.getPn_utilisateur());
        valeur.put(ID_REFERENCE_QUESTION, reponse.getId_ref_q());
        valeur.put(ID_UTILISATEUR_REPONSE, reponse.getId_utilisateur());
        db.insert(TABLE_REPONSE_FAQ, null, valeur);
        db.close();
    }

    //RECUPERER UNE REPONSE DE LA FAQ
    public FAQReponse getFAQReponse(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.query(TABLE_REPONSE_FAQ, new String[] { ID_FAQ_REPONSE,
                CONTENU_FAQR, PN_UTILISATEUR_REPONSE, ID_REFERENCE_QUESTION, ID_UTILISATEUR_REPONSE},
                ID_FAQ_REPONSE + "=?", new String[] {
                        String.valueOf(id) }, null, null,
                null, null);
        curseur.moveToFirst();
        FAQReponse _r = new FAQReponse(Integer.parseInt(curseur.getString(0)),
                curseur.getString(2), curseur.getString(1), Integer.parseInt(curseur.getString(3)),
                Integer.parseInt(curseur.getString(4)));
        return _r;
    }

    //RECUPERER TOUTES LES REPONSES
    public List<FAQReponse> getAllFAQReponse() {
        List<FAQReponse> liste_reponse = new ArrayList<FAQReponse>();
        String selectQuery = "SELECT * FROM " + TABLE_REPONSE_FAQ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor curseur = db.rawQuery(selectQuery, null);
        if(curseur.moveToFirst()) {
            do {
                FAQReponse reponse = new FAQReponse();
                reponse.setId(Integer.parseInt(curseur.getString(0)));
                reponse.setContenu(curseur.getString(2));
                reponse.setPn_utilisateur(curseur.getString(1));
                reponse.setId_ref_q(Integer.parseInt(curseur.getString(3)));
                reponse.setId_utilisateur(Integer.parseInt(curseur.getString(4)));
                liste_reponse.add(reponse);
            } while (curseur.moveToNext());
        }
        return liste_reponse;
    }

    //RECUPERER LE NOMBRE TOTAL DE REPONSES
    public int getNombreReponse() {
        String countQuery = "SELECT * FROM " + TABLE_REPONSE_FAQ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor curseur = db.rawQuery(countQuery, null);
        curseur.close();
        return curseur.getCount();
    }

    public void supprimerAllFAQReponse() {
        String deleteQuery = "DELETE FROM " + TABLE_REPONSE_FAQ;
        getWritableDatabase().execSQL(deleteQuery);
    }
}
