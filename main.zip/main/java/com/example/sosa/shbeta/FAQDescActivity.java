package com.example.sosa.shbeta;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FAQDescActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private List<String> rs = new ArrayList<String>();
    private String prenom = new String();
    private int id = 0;
    private int id_q;
    private FAQReponseTask mFaqRepTask = null;
    private EditText mReponseView;
    private View mAddFaqReponseFormView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faqdesc);

        //ON DECLARE UN OBJET DE SESSION
        final Session session = new Session(this.getApplicationContext());

        //ON EFFECTUE LES ACTIONS EN BASE NECESSAIRE POUR L AFFICHAGE DES INFORMATIONS
        DBHandler db = new DBHandler(this);
        List<Utilisateur> liste_utilisateur = db.getAllUtilisateur();
        List<FAQQuestion> liste_question = db.getAllFAQQuestion();
        String nom_prenom = new String();
        String email = new String();
        String sujet_q = new String();
        String q = new String();

        for (Utilisateur utilisateur : liste_utilisateur) {
            if (utilisateur.getId() == session.getIdUtilisateur()) {
                nom_prenom = utilisateur.getPrenom() + " " + utilisateur.getNom();
                email = utilisateur.getMail();
                prenom = utilisateur.getPrenom();
                id = utilisateur.getId();
            }
        }

        for (FAQQuestion faqQuestion : liste_question) {
            if (faqQuestion.getId() == session.getIdSujetFAQ()) {
                sujet_q = faqQuestion.getIntitule();
                q = faqQuestion.getContenu();
                id_q = faqQuestion.getId();
            }
        }

        List<FAQReponse> liste_reponse = db.getAllFAQReponse();
        int i = 0;
        while (i <= liste_reponse.size() - 1) {
            if (/*liste_reponse.get(i).getId_utilisateur() == id && */this.id_q == liste_reponse.get(i).getId_ref_q()) {
                rs.add(/*'n' + */"\"" + liste_reponse.get(i).getPn_utilisateur() + "\"           - " + liste_reponse.get(i).getContenu());
            }
            i++;
        }
        i = 0;
        String buff = new String();
        while (i <= rs.size() - 1) {
            buff += rs.get(i) + "\n\n";
            i++;
        }

        //ON DECLARE LA BARRE D OUTIL ET LE BOUTON FLOTANT
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();*/

        //ON DECLARE LES ELEMENTS DE LA PAGE DE LA FAQ
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header_utilisateur = navigationView.getHeaderView(0);
        TextView npView =(TextView)header_utilisateur.findViewById(R.id.nomPrenomView);
        TextView eView =(TextView)header_utilisateur.findViewById(R.id.emailView);
        TextView sujetView = (TextView)findViewById(R.id.txtsjtfaq);
        TextView qView = (TextView)findViewById(R.id.txtq);
        final TextView q_ansView = (TextView) findViewById(R.id.reponses);
        mReponseView = (EditText) findViewById(R.id.reponse);
        mAddFaqReponseFormView = findViewById(R.id.add_faqr_form);
        Button mAddFaqqButton = (Button) findViewById(R.id.add_faqr_button);


        //ON SET LES VUES AVEC LES INFORMATIONS CORRESPONDANTES
        navigationView.setNavigationItemSelectedListener(this);
        npView.setText(nom_prenom);
        eView.setText(email);
        sujetView.setText(sujet_q);
        qView.setText(q);
        q_ansView.setText(buff);
        db.close();

        //ON ECOUTE SUR LE BOUTON 'REPONDRE' ET ON EFFECTUE L ACTION
        mAddFaqqButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptAnswer();
            }
        });
    }

    //ON GERE LE COMPORTEMENT DU BOUTON RETOUR
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //ON VERIFIE LES INFORMATIONS ET ON EFFECTUE LES PREREQUIS POUR LA REPONSE
    private void attemptAnswer() {
        //ON DECLARE UN OBJET DE SESSION
        Session session = new Session(getApplicationContext());

        //ON REINITIALISE LES ERREURS
        mReponseView.setError(null);

        //ON STOCK LES VALEURS SAISIES
        String reponse = mReponseView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        //ON VERIFIE LA REPONSE
        if (TextUtils.isEmpty(reponse)) {
            mReponseView.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        //ON SET EN SESSION UN ID EN FONCTION POUR EVITERPAR LA SUITE UNE REINITIALISATION DE LA BASE
        if (cancel) {
            focusView.requestFocus();
            session.setIndexReponse(false);
        } else {
            mFaqRepTask = new FAQReponseTask(reponse, session);
            session.setIndexReponse(true);
            mFaqRepTask.execute((Void) null);
        }
    }

    //ON CREE UNE TACHE DE ANSWER OU ON FAIT CE QUE L ON SOUHAITE
    public class FAQReponseTask extends AsyncTask<Void, Void, Boolean> {
        private final String mReponse;

        //ON INSCRIT LA REPONSE EN BASE
        FAQReponseTask(String reponse, Session session) {
            DBHandler db = new DBHandler(getApplicationContext());

            Log.d("Insert ", "Insertion...");
            String prenom = db.getUtilisateur(session.getIdUtilisateur()).getPrenom();
            int id_ref = session.getIdSujetFAQ();
            int id_utilisateur = db.getUtilisateur(session.getIdUtilisateur()).getId();
            /*VERIFIER LES VALEURS*/
            db.ajouterFAQReponse(new FAQReponse(1, prenom, reponse, id_ref, id_utilisateur));
            mReponse = reponse;
            Log.d("AddAnswerTask ", "[R: " + mReponse + "]");
            db.close();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: remplacer par ce que l'on veut pendant le chargement au spinner.
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                return false;
            }
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mFaqRepTask = null;
            if (success) {
                //ON REDIRIGE l UTILISATEUR SUR LA PAGE DE LOGIN APRES SUCCES DE L INSCRIPTION
                Intent intent = new Intent(FAQDescActivity.this, FAQActivity.class);
                startActivity(intent);
                finish();
            } else {
                //ON SE FOCALISE SUR UNE ERREUR DE LOGIN [MDP pour le moment]
                mReponseView.setError(getString(R.string.error_field_required));
                mReponseView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mFaqRepTask = null;
        }
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //*FONCTION REQUISE POUR LA CLASSE*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {return true;}
        return super.onOptionsItemSelected(item);
    }

    //ON SELECTIONNE UN ITEM DANS LE MENU LATERAL ET ON DEMARE L ACTIVITE ASSOCIEE
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        Session session = new Session(getApplicationContext());
        Intent selection_intent = null;

        if (id == R.id.nav_accueil) {
            selection_intent = new Intent(FAQDescActivity.this, MenuActivity.class);
        } else if (id == R.id.nav_viesikh) {
            selection_intent = new Intent(FAQDescActivity.this, VieSikhActivity.class);
        } else if (id == R.id.nav_histoire) {
            selection_intent = new Intent(FAQDescActivity.this, HistoireActivity.class);
        } else if (id == R.id.nav_biographies) {
            selection_intent = new Intent(FAQDescActivity.this, BiographieActivity.class);
        } else if (id == R.id.nav_temples) {
            //selection_intent = new Intent(FAQDescActivity.this, TempleActivity.class);
        } else if (id == R.id.nav_faq) {
            selection_intent = new Intent(FAQDescActivity.this, FAQActivity.class);
        } else if (id == R.id.nav_quizz) {
            //selection_intent = new Intent(FAQDescActivity.this, QuizzActivity.class);
        } else if (id == R.id.nav_actualites) {
            //selection_intent = new Intent(FAQDescActivity.this, ActualiteActivity.class);
        } else if (id == R.id.nav_logout) {
            session.setIndexFirstConnexion(42);
            selection_intent = new Intent(FAQDescActivity.this, ReCoActivity.class);
        } else if (id == R.id.edit_info) {
            selection_intent = new Intent(FAQDescActivity.this, ModifierActivity.class);
        }
        startActivity(selection_intent);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
