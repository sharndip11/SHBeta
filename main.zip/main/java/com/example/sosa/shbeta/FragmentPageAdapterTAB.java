package com.example.sosa.shbeta;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Sharndip on 17/02/2017.
 */

public class FragmentPageAdapterTAB extends FragmentPagerAdapter{

    private String[] tabTitle = new String[] {"Onglet1", "Onglet2", "Onglet3", "Onglet4", "Onglet5", "Onglet6", "Onglet7"};

    Context context;

    private int pageCount = 7;

    public FragmentPageAdapterTAB(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        FragmentContentTAB fragmentContentTAB = new FragmentContentTAB();
        return fragmentContentTAB;
    }

    @Override
    public int getCount() {
        return pageCount;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabTitle[position];
    }
}
